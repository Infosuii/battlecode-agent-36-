// Draft logic: pick champions in a fixed priority order, skipping ones we already own.
#pragma once

void play_draft();

// Legacy descriptor classifier. Retained for disabled-switch parity only.
int nova_map_id(int w, int h, unsigned size, int groups);
// Exact immutable physical layout, absolute engine orientation; -1 on unavailable
// facts, changed layouts, unverified transforms, or when strict recognition is off.
// IDs use the same 0..16 order as nova_map_id. No shared/draft-memory writes.
int nova_official_map_id(int w, int h, unsigned size, int groups);
